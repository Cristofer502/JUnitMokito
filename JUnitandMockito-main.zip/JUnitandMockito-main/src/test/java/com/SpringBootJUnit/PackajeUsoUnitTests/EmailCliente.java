package com.SpringBootJUnit.PackajeUsoUnitTests;

public class EmailCliente {
    public void enviarCorreo(String direccion, String mensaje) {
        // Lógica para enviar correo electrónico
        System.out.println("Enviando correo a: " + direccion + " con mensaje: " + mensaje);
    }
}
