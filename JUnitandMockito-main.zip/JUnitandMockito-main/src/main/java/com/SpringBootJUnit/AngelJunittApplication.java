package com.SpringBootJUnit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngelJunittApplication {

	public static void main(String[] args) {
		SpringApplication.run(AngelJunittApplication.class, args);
	}

}
